﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using BillingProject.Configuration;
using BillingProject.Web;

namespace BillingProject.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class BillingProjectDbContextFactory : IDesignTimeDbContextFactory<BillingProjectDbContext>
    {
        public BillingProjectDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<BillingProjectDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            BillingProjectDbContextConfigurer.Configure(builder, configuration.GetConnectionString(BillingProjectConsts.ConnectionStringName));

            return new BillingProjectDbContext(builder.Options);
        }
    }
}
