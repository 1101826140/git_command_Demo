﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using BillingProject.Authorization.Roles;
using BillingProject.Authorization.Users;
using BillingProject.MultiTenancy;

namespace BillingProject.EntityFrameworkCore
{
    public class BillingProjectDbContext : AbpZeroDbContext<Tenant, Role, User, BillingProjectDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public BillingProjectDbContext(DbContextOptions<BillingProjectDbContext> options)
            : base(options)
        {
        }
    }
}
