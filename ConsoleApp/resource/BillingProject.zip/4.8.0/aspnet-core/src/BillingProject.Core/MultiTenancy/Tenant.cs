﻿using Abp.MultiTenancy;
using BillingProject.Authorization.Users;

namespace BillingProject.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
