using Abp.AspNetCore.Mvc.Controllers;
using Abp.IdentityFramework;
using Microsoft.AspNetCore.Identity;

namespace BillingProject.Controllers
{
    public abstract class BillingProjectControllerBase: AbpController
    {
        protected BillingProjectControllerBase()
        {
            LocalizationSourceName = BillingProjectConsts.LocalizationSourceName;
        }

        protected void CheckErrors(IdentityResult identityResult)
        {
            identityResult.CheckErrors(LocalizationManager);
        }
    }
}
