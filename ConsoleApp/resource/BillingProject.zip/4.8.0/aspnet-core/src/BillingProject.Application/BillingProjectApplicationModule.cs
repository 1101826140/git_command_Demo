﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using BillingProject.Authorization;

namespace BillingProject
{
    [DependsOn(
        typeof(BillingProjectCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class BillingProjectApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<BillingProjectAuthorizationProvider>();
        }

        public override void Initialize()
        {
            var thisAssembly = typeof(BillingProjectApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddMaps(thisAssembly)
            );
        }
    }
}
