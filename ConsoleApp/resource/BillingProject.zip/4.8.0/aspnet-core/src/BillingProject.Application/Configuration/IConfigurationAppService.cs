﻿using System.Threading.Tasks;
using BillingProject.Configuration.Dto;

namespace BillingProject.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
