﻿using System.Threading.Tasks;
using Abp.Application.Services;
using BillingProject.Sessions.Dto;

namespace BillingProject.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
