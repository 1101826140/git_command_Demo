using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using BillingProject.Roles.Dto;
using BillingProject.Users.Dto;

namespace BillingProject.Users
{
    public interface IUserAppService : IAsyncCrudAppService<UserDto, long, PagedUserResultRequestDto, CreateUserDto, UserDto>
    {
        Task<ListResultDto<RoleDto>> GetRoles();

        Task ChangeLanguage(ChangeUserLanguageDto input);
    }
}
