import { BillingProjectTemplatePage } from './app.po';

describe('BillingProject App', function() {
  let page: BillingProjectTemplatePage;

  beforeEach(() => {
    page = new BillingProjectTemplatePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
